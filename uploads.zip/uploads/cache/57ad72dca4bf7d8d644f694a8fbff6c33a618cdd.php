<header class="banner">
  <!-- <div class="container"> -->
  
    <nav class="navbar">

      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
                data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
        <span id="shield" class="navbar-toggler-icon">
          <img class="logo bw" src="<?= App\asset_path('images/logo_2019_bw.png'); ?>">
          <img class="logo color" src="<?= App\asset_path('images/logo_2019.png'); ?>">
        </span>
      </button>
      
        <!-- <a class="navbar-brand brand" href="<?php echo e(home_url('/')); ?>">logo here</a> -->

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          
          <?php if(has_nav_menu('primary_navigation')): ?>
            <?php echo wp_nav_menu(['theme_location' => 'primary_navigation', 'menu_class' => 'navbar-nav ml-auto']); ?>

          <?php endif; ?>

        </div>


    </nav>
 <!--  </div> -->
</header>