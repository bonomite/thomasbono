



<?php $__env->startSection('content'); ?>
  	
  	<?php echo $__env->make('bono-modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div id="details" class="section">
        <div class="container">
            
            
            	
            <div class="details">               
            	
                <?php if( have_rows('project',64) ): 

                	$id = $_GET['id']-1;
                	$rows = get_field('project',64);
					$specific_row = $rows[$id];
					
					$type = $specific_row['type'];
					$poster = $specific_row['poster'];
					$title = $specific_row['title'];
					$desc = $specific_row['desc'];
					$tools = $specific_row['tools-list'];
					$link = $specific_row['link'];
					$media = $specific_row['media'];
					$gallery = $specific_row['gallery'];
					$size = array(432,287);




					?>

					<div id="goBackArrow" data-where="<?php echo e($type[0]); ?>"><?php echo $__env->make('svgs.backButton', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>



					<?php 
					if( $gallery ): ?>
						<div class="masonry-grid">
						<div class="grid-item galleryImage item" style="height: 0; padding: 0;"></div>


							<?php 
						if( !empty($media) ): ?>						
							

							
							<?php foreach( $media as $item ): 

								$title = $item['title'];                        
		                        $image = $item['image'];                        
		                        $youtubeID = $item['youtubeID'];
		                        $codepenID = $item['codepenID'];
		                        $weblink = $item['weblink'];			                        
								//var_dump($item)
								?>

								<?php if(!empty($weblink)): ?>
							        <div class="grid-item item link">
							        	<a href="<?php echo e($weblink); ?>" target="_blank">
								        	<img src="<?php echo e($image); ?>">
								        	<?php echo $__env->make('svgs.link', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
							        	</a>
							        </div>
							    <?php elseif(!empty($youtubeID)): ?>							        
								    <div class="grid-item item video">
								    	<div class="videoWrapper">
								    		<iframe src="https://www.youtube.com/embed/<?php echo e($youtubeID); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
								    	</div>
									</div>
							    <?php elseif(!empty($codepenID)): ?>
							        <div class="grid-item item codepen">
								    	
											<iframe height="402" style="width: 100%;" scrolling="no" title="SVG Morph" src="//codepen.io/bonomite/embed/<?php echo e($codepenID); ?>/?height=402&theme-id=dark&default-tab=result" frameborder="no" allowtransparency="true" allowfullscreen="true">
											  See the Pen <a href='https://codepen.io/bonomite/pen/<?php echo e($codepenID); ?>/'>SVG Morph</a> by Thomas Bono
											  (<a href='https://codepen.io/bonomite'>@bonomite</a>) on <a href='https://codepen.io'>CodePen</a>.
											</iframe>
									</div>
							    <?php endif; ?>
								
								
							<?php endforeach; ?>
							
						<?php endif; ?>


					        <?php foreach( $gallery as $image ): ?>
					            
						    	<div class="grid-item item galleryImage" data-img="<?php echo e($image['url']); ?>">
					            	<?php echo wp_get_attachment_image( $image['ID'], $size ); ?>
					            	<div class="enlarge-icon"><?php echo $__env->make('svgs.enlarge', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
						    	</div>

					        <?php endforeach; ?>
				    	</div>

					<?php endif; ?>

					
					
                        
                <?php endif; ?>
				

            
            </div>
	            
	            
	        
	    </div>
	</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>