



<?php $__env->startSection('content'); ?>
	<?php 
        $pagename = get_query_var('pagename');
    ?>
	<div id="presentation">

        

        <?php echo $__env->make('presentations.'.$pagename, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 

         
    </div>
    <?php ?>
    <div id="portfolio" class="section pt-0">
        <div class="container">
                        
            	
            <div class="row projects">               
            	
                <?php if( have_rows('project',64) ): 
                        $pagename = get_query_var('pagename');
                    
                    while( have_rows('project',64) ): the_row(); 

                        $type = get_sub_field('type');
                        $poster = get_sub_field('poster');                        
                        $title = get_sub_field('title');                        
                        $link = get_sub_field('link');

                        $urlvar = strtolower(implode('-',explode(" ", $title)));
                        $index = get_row_index();

                        
                        ?>

                        <?php if(in_array($pagename, $type)): ?>

                        <div class="col-sm-6 col-lg-4">
                            
                            <!-- <img class="poster" src="<?php echo e($poster); ?>"> -->
                            <div class="poster bw" data-index="<?php echo e($index); ?>" data-title="<?php echo e($urlvar); ?>" style="background-image: url(<?php echo e($poster); ?>);"></div>
                            
                        </div>

                        <?php endif; ?>
                    

                    <?php endwhile; ?>
                        
                <?php endif; ?>
            
            </div>
	            
	            
	        
	    </div>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>