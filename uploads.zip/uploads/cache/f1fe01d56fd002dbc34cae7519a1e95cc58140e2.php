<? xml version = "1.0" encoding = "UTF-8" standalone = "no"?>
 <svg version="1.1" id="hamburgerCloser" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
    viewBox="0 0 24.5 24.3" style="enable-background:new 0 0 24.5 24.3;" xml:space="preserve">
    <style type="text/css">
    #hamburgerCloser .st0{fill:#000000;}
    </style>
    <path class="st0" d="M23.2,3.1L3.4,22.9c-0.6,0.6-1.5,0.6-2.1,0l0,0c-0.6-0.6-0.6-1.5,0-2.1L21.1,1c0.6-0.6,1.5-0.6,2.1,0l0,0
    C23.8,1.6,23.8,2.5,23.2,3.1z"/>
    <path id="Rectangle_11_copy_2" class="st0" d="M3.4,1l19.8,19.8c0.6,0.6,0.6,1.5,0,2.1l0,0c-0.6,0.6-1.5,0.6-2.1,0L1.3,3.1
    C0.7,2.5,0.7,1.6,1.3,1l0,0C1.9,0.4,2.8,0.4,3.4,1z"/>
</svg>