<? xml version = "1.0" encoding = "UTF-8" standalone = "no"?>
<svg version="1.1" id="hamburger" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
    viewBox="0 0 31 19.1" style="enable-background:new 0 0 31 19.1;" xml:space="preserve">
    <style type="text/css">
    #hamburger .st0{fill:#000000;}
    </style>
    <path id="topLine" class="st0" d="M1.5,0h28C30.3,0,31,0.7,31,1.5l0,0C31,2.3,30.3,3,29.5,3h-28C0.7,3,0,2.3,0,1.5l0,0C0,0.7,0.7,0,1.5,0z"/>
    <path id="bottomLine" class="st0" d="M1.5,16.1h28c0.8,0,1.5,0.7,1.5,1.5s-0.7,1.5-1.5,1.5h-28c-0.8,0-1.5-0.7-1.5-1.5
    S0.7,16.1,1.5,16.1L1.5,16.1z"/>
    <path id="middleLine" class="st0" d="M1.5,8h28C30.3,8,31,8.7,31,9.5l0,0c0,0.8-0.7,1.5-1.5,1.5h-28C0.7,11,0,10.4,0,9.5
    l0,0C0,8.7,0.7,8,1.5,8z"/>
</svg>